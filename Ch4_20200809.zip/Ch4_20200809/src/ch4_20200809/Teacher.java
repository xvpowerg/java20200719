/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809;

/**
 *
 * @author xvpow
 */
public class Teacher extends Person {
	public Teacher(String name,
		int age,float height){
	    super(name,age,height);
	}
 
    @Override	
    public void print(){
	System.out.print("Teacher ");
	super.print();
    }	
	
}
