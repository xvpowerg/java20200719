/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809;

/**
 *
 * @author xvpow
 */
public class Ch4_1 {
    public static void main(String[] args) {
	Person p1 = new Person();
	p1.setAge(25);
	p1.setHeight(150);
	p1.setName("Joy");
	p1.print();
	//繼承會繼承到 父類型的
	//1 能看到的非靜態方法
	//2 能看到的屬性
	Student st1 = new Student();
	st1.setAge(16);
	st1.setHeight(165);
	st1.setName("Tom");
	st1.print();
	
	

    }
    
}
