/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.override;

public class Ch4_8 {
    //Override規則
    //以下規則都是在父類別的方法能被看到的情況
    //1 讀取權限只能開放不能封閉
    //2 回傳值如果是基本型態必須一樣
    //3 回傳值如果是參考型態可以是子類型或一樣
    //4 方法名稱與參數類型數量要一樣
    //5 例外可選擇拋出一樣或子類或不拋出
    public static void main(String[] args) {
	TestOverride1 t1 = new TestOverride2();
	t1.publicMethod();
	t1.protectedMethod();
	t1.defaultMethod();
    }
    
}
