/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.override;

/**
 *
 * @author xvpow
 */
public class TestOverride1 {
    public void publicMethod(){
	System.out.println("T1 publicMethod");
    }
    
    protected void protectedMethod(){
	System.out.println("T1 protectedMethod");
    }
    void defaultMethod(){
	System.out.println("T1 defaultMethod");
    }
    
    private void privateMethod(){
	System.out.println("T1 privateMethod");
    }
    
}
