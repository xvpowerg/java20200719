/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.override;
import ch4_20200809.Student;
import ch4_20200809.Teacher;
public class Ch4_4 {

    
    public static void main(String[] args) {
    //練習覆寫
	Student st1 = new Student("Ken",10,150);
	Teacher ter1 = new Teacher("Lucy",21,165);
	
	st1.print();
	ter1.print();
    }
    
}
