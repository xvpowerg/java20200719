/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.override;

/**
 *
 * @author xvpow
 */
public class TestOverride2 extends TestOverride1 {
    //public 只能用public覆寫
    public void publicMethod(){
	 System.out.println("TestOverride2 publicMethod");
    }
    //protected 可用protected 或 public 方式覆寫
    protected void protectedMethod(){
	 System.out.println("TestOverride2 protectedMethod");
    }
   //default 可用protected 或 public 或 default 方式覆寫
    void defaultMethod(){
	System.out.println("TestOverride2 defaultMethod");
    }
    //他是一個新方法不算覆寫
    //@Override
     void privateMethod(){
	System.out.println("TestOverride2 privateMethod");
    }
}
