/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.override;

import ch4_20200809.Student;
import ch4_20200809.Teacher;
import ch4_20200809.Person;

public class Ch4_5 {
    static void printPerson(Person ... sts){
	for (Person s : sts){
	    s.print();
	}
    }
    public static void main(String[] args) {
	//練習多型
	Student st1 = new Student("Ken",10,120);
	Student st2 = new Student("Viivn",25,160);
	Student st3 = new Student("Lindy",18,170);
	printPerson(st1,st2,st3);
	
	Teacher t1 = new Teacher("Tom",15,156);
	Teacher t2 = new Teacher("Gigi",19,165);
	Teacher t3 = new Teacher("Sean",26,180);
	printPerson(t1,t2,t3);
    }
}
