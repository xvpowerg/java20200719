/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809;

/**
 *
 * @author xvpow
 */
public class Ch4_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	
	   //new Person();
	   //new Student();
	   Person p2 = new Person("Tom",12,135);
	   p2.print();
	   
	   //測試建構子是否繼承
	   //建構子不會繼承
	 Student st1 = new Student("Ken",16,170);
	 st1.print();
	 
	Student st2 = new Student();
        st2.print();//未填寫:-1:-1
	   
    }
    
}
