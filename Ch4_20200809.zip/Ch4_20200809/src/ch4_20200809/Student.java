/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809;


public class Student extends Person{
    //會自動呼叫父類預設建構子
   public Student(){
	//this() 呼叫目前物件中的其他建構子
	//this()的位置只能是建構子的第一個命令
	this("未填寫",-1,-1);
    }
   public Student(String name,int age,float height){
	//呼叫父類建構子
	//super()的位置只能是建構子的第一個命令
	super(name,age,height);
//	this.setName(name);
//	this.setAge(age);
//	this.setHeight(height);
    }
   //@Override 驗證覆寫是否成功
   @Override
   public void print(){
       System.out.print("Student ");
       super.print();
   }
}
