/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.modifier;

/**
 *
 * @author xvpow
 */
public class Ch4_6 {
    //Test Modifier 1 在相同Package的情況
//public 在java所有地方都可讀取 如果是public類別記得在不同Package記得要import  
//protected 只有在相同package才能讀取 繼承後在子類別內可讀取   
//default 只有在相同package才能讀取    
//private 只能在宣告的類別內讀取
    
    public static void main(String[] args){
	TestModifier t1 = new TestModifier();
	System.out.println(t1.testDefault);
	System.out.println(t1.testProtected);
	System.out.println(t1.testPublic);
    }
}
