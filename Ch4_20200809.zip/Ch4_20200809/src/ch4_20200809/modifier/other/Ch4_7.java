/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.modifier.other;
import ch4_20200809.modifier.TestModifier;

/**
 *
 * @author xvpow
 */
public class Ch4_7 extends TestModifier {
   //Test Modifier  不同Package的情況
    public  void testProtected(){
	System.out.print(this.testProtected );
    }
    //靜態的不能呼叫非靜態的
    public static void main(String[] args) {
	TestModifier  t2 =  new TestModifier();
	System.out.print(t2.testPublic);
	Ch4_7 ch47 = new Ch4_7();
	ch47.testProtected();
    }
    
}
