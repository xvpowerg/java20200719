/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.modifier;

/**
 *
 * @author xvpow
 */
public class TestModifier {
    
    public String testPublic = "testPublic!!";
    protected  String testProtected = "testProtected";
    String testDefault = "testDefault";
    private String testPrivate  = "testPrivate";
}
