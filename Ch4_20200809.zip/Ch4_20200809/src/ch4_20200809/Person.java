/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809;


public class Person {
    private String name;
    private int age;
    private float height;
    //建構子的長相
    //沒有回傳值
    //方法名稱跟類別一樣
    //預設建構子(constructor)
    //當沒有任何建構子時java會自動補上預設建構子
     Person(){
	System.out.println("Person()");
     }
     Person(String name,int age,float height){
	 this.setName(name);
	 this.setAge(age);
	 this.setHeight(height);
     }
    
    public void setName(String inName){
	name = inName;
    }
    public String getName(){
	return name;
    }
    public void setAge(int inAge){
	age = inAge;
    }
    public int getAge(){
	return age;
    }
    public void setHeight(float height){
	//this 表示當前物件 
	this.height = height;
    }
    public float getHeight(){
	return height;
    }
    public void print(){	
	System.out.println(name+":"+age+":"+height);
    }    
}
