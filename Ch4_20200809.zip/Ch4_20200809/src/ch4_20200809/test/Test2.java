/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.test;
public class Test2 extends Test1 {
    Test2(){System.out.println("Test2()");}
    Test2(String value3,int value4){
	this();
	System.out.println("Test2 String int");
    }
}
