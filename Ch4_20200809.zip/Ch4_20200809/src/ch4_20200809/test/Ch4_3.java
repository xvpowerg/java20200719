/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.test;
public class Ch4_3 {
    public static void main(String[] args) {
	// TODO code application logic here
	//建構子考題
	//Test3 t3 = new Test3();
	Test3 t3 = new Test3("Vivin");
    }
    
}
