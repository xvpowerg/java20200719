/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.test;
public class Test3 extends Test2 {
    Test3(){
	super("Ken",25);
	System.out.println("Test3()");
    }
    Test3(String name){
	System.out.println("Test3(String)");
    }    
}
