/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20200809.test;

/**
 *
 * @author xvpow
 */
public class Test1 {
   Test1(){
       this("Value1",25);
       System.out.println("Test1()");
   }
   Test1(String v1,int v2){
       System.out.println("Test1(String,int)");
       System.out.println(v1+":"+v2);
   }
}
