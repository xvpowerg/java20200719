/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override;


public class TestOverride2 extends TestOverride1 {
       // 回傳值如果是基本型態必須一樣
     public int testReturnValue(){
	 System.out.println("TestOverride2 int ");
	return 20;
    }
     
     //3 回傳值如果是參考型態可以是子類型或一樣
@Override     
     public TestOverride1 testReturnValue2(int obj){
	 System.out.println("TestOverride2 testReturnValue2!");
	TestOverride2 to2 =  new TestOverride2();
	return to2;
    }
    //5 例外可選擇拋出一樣
//   public void testException()throws MyException2 {
//	System.out.println("TestOverride2 Exception");
//    }
       //5 例外可選擇拋出子類
//   public void testException()throws MyException3 {
//	System.out.println("TestOverride2 Exception");
//    }
     //5 例外可選擇不拋出
        public void testException() {
	System.out.println("TestOverride2 Exception");
    }
}
