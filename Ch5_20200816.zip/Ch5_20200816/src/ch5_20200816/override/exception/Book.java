/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override.exception;
public class Book {
    private int price;
    private String name;
   public Book(){}
   public void setPrice(int price)throws Exception{
       if (price < 0 || price >= 1000000){
//	   System.out.println("輸入錯誤的金額");
	   throw new Exception("輸入錯誤的金額");
       }
       this.price = price;
   }
   public int getPrice(){
       return price;
   }
   public void setName(String name){
       this.name = name;
   }
   public String getName(){
       return name;
   }
   public void print(){
       System.out.println(getName()+":"+getPrice());
   }
}
