/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override.exception;

/**
 *
 * @author xvpow
 */
public class Ch5_6 {

    
    
    
    public static void main(String[] args) {
	
	TestException tex = new TestException();
	try{
	    tex.testReportException();    
	}catch(ReportFormatException ex){
	    System.out.println(ex);
	}
	
	tex.testNotCloseException();
	
    }
    
}
