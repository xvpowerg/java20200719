/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override.exception;

public class Ch5_2 {
    public static void main(String[] args) {	
	try{
	    System.out.println("選書!");
	    Book b1 = new Book();
	    b1.setName("Android");
	    //希望 當 金額 小於0大於1000000 會出現
	    //輸入錯誤的金額
	    b1.setPrice(-650);
	    System.out.println("結帳");
	    b1.print();
	}catch(Exception ex){
	    System.out.println(ex);
	}	
    }
}
