/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override.exception;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.sql.SQLException;
/**
 *
 * @author xvpow
 */
public class TestException {
    //checked exceptions
    // FileNotFoundException 是 IOException 子類
    //SQLException
    //通常是無法檢查 或常發生的 我會分在Checked類型
    public void testCheckedException(int a)throws IOException{	
	if (a == 1){
	    throw new IOException("testCheckedException");
	}	
    }
    public void testCheckedException2(int b)throws IOException,SQLException,FileNotFoundException{	
	switch(b){
	    case 1:
		throw new IOException();
	    case 2:
		throw new SQLException();
	    case 3:
		throw new FileNotFoundException();
	}
    }
    //好解決不常發生的unchecked
    public void uncheckedException(int c){
	if (c == 1)
	    throw new IllegalArgumentException("c不可為1");
	
    }
    
    
    public void testReportException() throws ReportFormatException{
	throw new ReportFormatException();
    }
    
    public void testNotCloseException(){
	throw new NotCloseException();
    }
}
