/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override.exception;

/**
 *
 * @author xvpow
 */
public class Ch5_5 {
    public static void main(String[] args) {
	
	  TestException ex = new TestException();
	   ex.uncheckedException(1);

    }
    
}
