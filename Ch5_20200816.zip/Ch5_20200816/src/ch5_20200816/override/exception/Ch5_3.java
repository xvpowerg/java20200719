/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override.exception;
import java.io.IOException;
/**
 *
 * @author xvpow
 */
public class Ch5_3 {

    public static void main(String[] args)throws IOException {
	//測試無try catch的狀況
	TestException te1 = new TestException();
	te1.testCheckedException(1);

    }
    
}
