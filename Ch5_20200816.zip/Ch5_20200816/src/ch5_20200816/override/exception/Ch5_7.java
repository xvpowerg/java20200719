/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override.exception;

/**
 *
 * @author xvpow
 */
public class Ch5_7 {

 
    public static void main(String[] args) {
	TestException tex = new TestException();
	System.out.println("開始");
	try{
	    System.out.println("計算");
	    tex.testReportException();
	    System.out.println("完成");
	}catch(ReportFormatException ex){
	    System.out.println(ex);
	}finally{
	      System.out.println("上傳狀態");//這個動作一定要作一次請放在finally
	}
	
	try{
	
	}finally{  }
	
    }
    
}
