/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override.exception;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.sql.SQLException;
public class Ch5_4 {
    public static void main(String[] args) {
	//測試有try catch的狀況
	try{
	  TestException ex = new TestException();
	  ex.testCheckedException(1);
	}catch(IOException ex){
	    System.out.println("錯誤訊息:"+ex);
	}
	//當方法有拋出多個例外時的catch方式
	//越下越父
	try{
	     TestException ex = new TestException();
	     ex.testCheckedException2(3);
	}catch(FileNotFoundException ex){
	    System.out.println(ex);
	}catch(IOException ex){
	    System.out.println(ex);
	}catch(SQLException ex){
	      System.out.println(ex);
	}
	
    }
}
