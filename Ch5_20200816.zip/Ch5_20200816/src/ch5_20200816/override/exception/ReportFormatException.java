/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override.exception;


public class ReportFormatException extends Exception {
      public ReportFormatException(){
	  super("錯誤的報表格式");
      }
}
