/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override;

/**
 *
 * @author xvpow
 */
public class Ch5_8 {

  
    public static void main(String[] args)throws MyException2 {
	
	TestOverride1 to1 = new TestOverride2();
	to1.testException();
    }
    
}
