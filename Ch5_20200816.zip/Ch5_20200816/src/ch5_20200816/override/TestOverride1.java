/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.override;

/**
 *
 * @author xvpow
 */
public class TestOverride1 {
 
    public int testReturnValue(){
	return 10;
    }
    
    public TestOverride1 testReturnValue2(int obj){
	TestOverride1 to1 = new TestOverride1();
	return to1;
    }
    
    public void testException()throws MyException2 {
	
    }
}
