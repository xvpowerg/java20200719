/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.comm.override;

/**
 *
 * @author xvpow
 */
public class Person {
   private String name;
   private float height;
   
   public Person(String name,float height){
       this.name = name;
       this.height = height;
   }
   
   public void print(){
       System.out.
	       println(this.name+":"+this.height);
   }
   
   public String toString(){
       return name+":"+height;
   }
   public boolean equals(Object obj){
       //obj instanceof Person 如果obj 是 Person回傳true 
       if (obj == null || obj instanceof Person == false){
	   return false;
       }
       Person tmp = (Person)obj;
       boolean ans = this.height==tmp.height
	       &&  name.equals(tmp.name);
       return ans;
   }
}
