/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.comm.override;

/**
 *
 * @author xvpow
 */
public class Ch5_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Person p1 = new Person("Ken",156);
	Person p2 = new Person("Ken",156);
	//p1.print();
	System.out.println(p1);
	System.out.println(
		p1.getClass().getName()+"@"+
			Integer.toHexString(p1.hashCode()));
	Object obj = new Object();
	System.out.println(p1.equals(obj));
    }
    
}
