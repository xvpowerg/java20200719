/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.teststatic;

/**
 *
 * @author xvpow
 */
public class Ch5_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	TestStatic ts1 = new TestStatic();
	TestStatic ts2 = new TestStatic();
	//非Static 是資源獨自擁有
	ts1.salary = 25000;
	ts2.salary = 56000;
	System.out.println("ts1:"+ts1.salary);
	System.out.println("ts2:"+ts2.salary);
	//Static 是資源共享
	ts1.price = 95000;
	ts2.price = 15000;
	System.out.println("ts1:"+ts1.price);
	System.out.println("ts2:"+ts2.price);
	
    }
    
}
