/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.init;

/**
 *
 * @author xvpow
 */
public class Ch5_11 {

    //靜態區塊與非靜態區塊的執行順序
    public static void main(String[] args) {
	// TODO code application logic here
	//靜態區塊
	//非靜態區塊
	//建構子
	//靜態區塊 只會呼叫一次
	//非靜態區塊會呼叫 n次  n是看new了幾次
	TestInitOrder order = new TestInitOrder();
	TestInitOrder order2 = new TestInitOrder();
    }
    
}
