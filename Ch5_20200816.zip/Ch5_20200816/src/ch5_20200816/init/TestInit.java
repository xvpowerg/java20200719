/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.init;
import java.util.Arrays;

public class TestInit {
   private String[] names = new String[100];
   TestInit(){ }
   TestInit(int a){}
   {
    Arrays.fill(names, "");  
   }
   public String getName(int index){
       return names[index];
   } 
}
