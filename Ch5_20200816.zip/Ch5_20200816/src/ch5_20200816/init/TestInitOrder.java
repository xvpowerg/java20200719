/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.init;

/**
 *
 * @author xvpow
 */
public class TestInitOrder {
    TestInitOrder(){
	System.out.println("TestInitOrder()");
     }
    {
	System.out.println("Init 1");
    }
    static{
    System.out.println("static Init 1");
    }
    {
     System.out.println("Init 2");
    }
    static{
	 System.out.println("static Init 2");
    }
}
