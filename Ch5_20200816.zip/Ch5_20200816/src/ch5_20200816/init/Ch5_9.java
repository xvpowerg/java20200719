/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20200816.init;

/**
 *
 * @author xvpow
 */
public class Ch5_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	TestInit t = new TestInit();
	String name = t.getName(2);
	if (name.isEmpty()){
	   System.out.println("name為空白");
	}
    }
    
}
