/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20200913;

/**
 *
 * @author xvpow
 */
public class Zoo {
    public static final int  PIG = 1231123;
    public static final int  TIGER = 1634631232;
     public static final int  MONKEY =798783;
     
     enum Animal{
	 PIG,
	 TIGER,
	 MONKEY
     }
       public static void printAnimalEnum(Animal animal){
	switch( animal){
	    case PIG:
		System.out.println("PIG");
	       break;
	    case TIGER:
		System.out.println("TIGER");
		break;
	    case MONKEY:
		System.out.println("MONKEY");
		break;
	}
       }
    public static void printAnimal(int type){
	switch( type){
	    case PIG:
		System.out.println("PIG");
	       break;
	    case TIGER:
		System.out.println("TIGER");
		break;
	    case MONKEY:
		System.out.println("MONKEY");
		break;
	}
    }
    
    
}
