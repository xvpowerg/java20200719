/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200906;
import java.util.function.Supplier;
import java.util.ArrayList;
import java.util.List;
public class Ch8_10 {
	
     static List<String> stringArrayToList(Supplier<ArrayList> sp,
	     String ... values){
	   ArrayList list =  sp.get();
	   for (String v : values){
	       list.add(v);
	   }
	   return list;
     }
    public static void main(String[] args) {
	//使用new 的method  reference
	    /*1. 觀察 Function Interface 參數類型與數量
	    2. 觀察 Function Interface 必須有回傳 與回傳值類型
	    3. 由第1步驟 與 第2步驟 撰寫或是查看 是否有相同的建構子
	    4. 第1步驟影響 呼叫哪一組建構子，會依照參數的數量與類型去呼叫相對應的建構子，如無對應會出錯
	    5. 第2步驟影響 method  reference呼叫的類別*/

	    stringArrayToList(()->new ArrayList(),"AA","BB","CC");
	   List<String> list = stringArrayToList(ArrayList::new,"AA","BB","CC");
	   System.out.println(list);
    }
    
}
