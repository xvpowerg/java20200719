/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20200906;

/**
 *
 * @author xvpow
 */
public class Ch8_3 {

    // Function Interface才可使用lambda
    //Function Interface 介面當中抽象的方法只有一個
    
    static void testCopy(int[] data,CopyFile cp){
	cp.copy(data);
    }
    public static void main(String[] args) {
	//Function Interface 的方法參數只有一組且無回傳值
	   //標準寫法
	   int[] data = {56,30,92};
	   CopyFile c1 = (int[] a)->{	       
	       System.out.println("C1:"+a[0]);
	   };	   
	   testCopy(data,c1);
	   //簡寫1 大括號內只有一條命令，所以可以使用以下方式簡寫
	   //可把{}移除 也要注意{}內部命令;記得要移除
	   //; 表達的是一段命令結束
	     CopyFile c2 = (int[] a)->       
	       System.out.println("C2:"+a[0]);
	    testCopy(data,(int[] a)->System.out.println("C2:"+a[0]));
	   //簡寫2
	    // 因為方法傳遞的參數只有一組,所以可使用 移除()變數類型 方式簡寫
	      CopyFile c3 = (a)->{
		    System.out.println("C3:"+a[0]); 
		 };     
	      
	       CopyFile c4 = a ->{
		    System.out.println("C3:"+a[0]); 
		 };       	     
	   //簡寫3 由簡寫2與簡寫1規則合併
	     CopyFile c5 = a->System.out.println("C3:"+a[0]); 
	

	
	
	
    }
    
}
