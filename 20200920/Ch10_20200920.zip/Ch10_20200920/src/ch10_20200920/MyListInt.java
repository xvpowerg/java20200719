/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20200920;
import java.util.ArrayList;
import java.util.function.Consumer;

/**
 *
 * @author xvpow
 */
public class MyListInt {
    private ArrayList<Integer> list = new ArrayList<>();
    public void add(Integer str){
	list.add(str);
    }
    
    public Integer get(int index){
	return list.get(index);
    }
    
    public void foreach(Consumer<Integer> consumer){
	list.forEach(consumer);
    }
}
