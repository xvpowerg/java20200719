/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myabstract;

/**
 *
 * @author xvpow
 */
//因為Book是一種通稱所以設為 abstract
public abstract class Book {
    private String name;
    private String author;
    private int price;
    
    public Book(String name,String author,int price){
	    this.name =name;
	    this.author = author;
	    this.price = price;
    }
    
    public String toString(){
	return name+":"+author+":"+price;
    }
}
