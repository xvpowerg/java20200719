/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myabstract;

/**
 *
 * @author xvpow
 */
public class NameList extends ListAdapter{
    private String[] names = new String[1000];
    private int len = 0;    
    
    public int size(){
	return len;
    }
    public String getItem(int index){
	return getName(index);
    }
    public void addName(String name){
	names[len++] = name;
    }
    public String getName(int index){
	//index 小0 或 大於等於 len 
	//拋出new IllegalArgumentException()
	//例外顯示訊息 index 錯誤
	if (index < 0 || index >= len ){
	    throw new IllegalArgumentException("index 錯誤");
	}
	return names[index];
    }
    
}
