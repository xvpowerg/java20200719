/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myabstract;

/**
 *
 * @author xvpow
 */
public class StudentList extends ListAdapter{    
    public int size(){
	return size;
    }
    public String getItem(int index){
	Student st = getStudent(index);
	return st.toString();
    }
    private Student[] stArray = new Student[1000];
    private int size = 0;
    public void addStudent(Student st){
	stArray[size++] = st;
    }
    public Student getStudent(int index){
	return stArray[index];
    }
}
