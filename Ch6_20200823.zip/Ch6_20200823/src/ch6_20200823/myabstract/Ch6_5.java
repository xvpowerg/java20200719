/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myabstract;
public class Ch6_5 {

    static void printList(ListAdapter la){
	la.foreach();
    } 
    
    public static void main(String[] args) {
	NameList nameList = new NameList();
	nameList.addName("Ken");
	nameList.addName("Vivin");
	nameList.addName("Join");
	nameList.addName("Iris");
	nameList.addName("Lucy");
	printList(nameList);
	
    }
    
}
