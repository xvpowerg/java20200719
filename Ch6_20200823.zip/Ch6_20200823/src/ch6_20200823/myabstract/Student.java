/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myabstract;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private int age;
    public Student(String name,int age){
	this.name = name;
	this.age = age;
    }
    public String getName(){
	return name;
    }
    public int getAge(){
	return age;
    }    
    public String toString(){
	return getName()+":"+getAge();
    }
}
