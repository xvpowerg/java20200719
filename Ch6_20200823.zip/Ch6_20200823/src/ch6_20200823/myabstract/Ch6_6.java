/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myabstract;

/**
 *
 * @author xvpow
 */
public class Ch6_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Student st1 = new Student("Ken",10);
	Student st2 = new Student("Vivin",25);
	Student st3 = new Student("Iris",17);
	StudentList stList = new StudentList();
	stList.addStudent(st1);
	stList.addStudent(st2);
	stList.addStudent(st3);
	Ch6_5.printList(stList);//希望能顯示
	// "Ken:10"
	// "Vivin:25"
	// "Iris:17"
    }
    
}
