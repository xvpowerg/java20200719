/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.shade;

/**
 *
 * @author xvpow
 */
public class Test2 extends Test1 {
	public String name = "Test2";
    	public void method(){
	    System.out.println("Test2 method");
	}
}
