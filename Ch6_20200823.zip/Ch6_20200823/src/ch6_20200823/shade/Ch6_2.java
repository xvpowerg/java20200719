/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.shade;

/**
 *
 * @author xvpow
 */
public class Ch6_2 {
        public static void main(String[] args) {
	    //遮蔽的含意
	//所有屬性都是遮蔽
	//所靜態的都是遮蔽
	//討論的是 當 子類與父類別有相同屬性名稱時
	//討論的是 當 子類與父類別有相同靜態方法名稱時
	
	//遮蔽定理
	//1 遮蔽看類別
	//2 覆寫看物件
	Test3 t3 = new Test4();
	t3.staticMethod();
	}
}
