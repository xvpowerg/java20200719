/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.shade;

/**
 *
 * @author xvpow
 */
public class Test6  extends Test5{
    public String value;    
    public String getValue(){
	return value;
    }
    
}
