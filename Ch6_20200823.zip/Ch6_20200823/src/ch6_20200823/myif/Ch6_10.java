/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myif;
import java.util.List;
import java.util.function.Supplier;

public class Ch6_10 {
    static void printString(String data,Supplier<Integer> sup){
	    int v =  sup.get();	    
	 System.out.println(data+v);
    } 

    public static void main(String[] args) {
	RadomSupplier rs = new RadomSupplier();
	printString("point:",rs);
	printString("point:",rs);
    }
}
