/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myif;
import java.util.function.Consumer;
public class Ch6_9 {
    //Consumer 收某種東西  做某些事情  
    static void  receive(String[] data,Consumer<String> con){
	for (String s : data){
	    con.accept(s);
	}
    }
    public static void main(String[] args) {
	//常用java內建介面
	//Consumer<T> void	accept(T t) //負責接收
	//Supplier<T> T	get() //的到某個東西
	//Function<T,R> R apply(T t) //用來轉換
	//Predicate<T> boolean	test(T t)//用驗證
	//UnaryOperator<T>  apply(T t)//對本身做計算
	String[] name = {"Ken","Vivin","Join"};
//	PrintConsumer pc = new PrintConsumer("");
//	receive(name,pc);
	String[] copyName = new String[name.length];
	CopyConsumer cc = new CopyConsumer(copyName);
	receive(name,cc);
	PrintConsumer pc = new PrintConsumer("copy:");
	receive(copyName,pc);
	
    }
    
}
