/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myif;
import java.util.function.Supplier;
import java.util.Random;
/**
 *
 * @author xvpow
 */
public class RadomSupplier  implements Supplier<Integer>{
    private Random random = new Random();
    public Integer get(){
	return random.nextInt(500);//0~499
    }
    
    //產生大樂透的方法
    //Supplier 提供 7數字當中的某一個數字
    //1~49 
     // 7
}
