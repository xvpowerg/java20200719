/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myif;

/**
 *
 * @author xvpow
 */
public class Ch6_7 {


    public static void main(String[] args) {
	//介面
	//如動作:開心 跳 跑 等技能
	//協定:藍芽 USB3.0 ....
	//表示某一種方法
	AirPlane ap = new AirPlane();
	Fly fly = ap;
	fly.flying();
	Run run = ap;
	run.runing();
    }
    
}
