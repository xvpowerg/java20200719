/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myif;

/**
 *
 * @author xvpow
 */
public class IronMan implements IronManIF {
    public void flying(){
	System.out.println("IronMan flying");
    }
    public void runing(){
	System.out.println("IronMan runing");
    }
     public int attacking(){
	System.out.println("IronMan attacking");
	return 10;
    }
}
