/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myif;

/**
 *
 * @author xvpow
 */
public class Ch6_8 {

    static void testFly(Fly fly){
	fly.flying();
    }
    static void testRun(Run run){
	run.runing();
    }
      static void testAttack(Attack attack){
	attack.attacking();
    }
    public static void main(String[] args) {
	AirPlane ap = new AirPlane();
	testFly(ap);
	testRun(ap);
	
	IronMan im = new IronMan();
	testFly(im);
	testRun(im);
	 testAttack(im);
    }
    
}
