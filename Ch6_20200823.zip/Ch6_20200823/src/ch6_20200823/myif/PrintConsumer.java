/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20200823.myif;
import java.util.function.Consumer;
public class PrintConsumer implements Consumer<String>  {
    private String title;
    public PrintConsumer(String title){	
	this.title = title;
    }
    
    public void accept(String v){
	System.out.println(title+v);
    }
}
