/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;

/**
 *
 * @author xvpow
 */
public class Ch2_2 {
    public static void main(String[] args) {
	//陣列宣告的特色
	// 左邊的[] 數量加起來等於右邊的[]
	 int[] array1 = new int[5];//* java
	 int array2[] = new int[3];
	//只能在 "宣告時"給予數值使用
	 int[] array3 = {5,7,8,2};
	 //array3 = {77,88}; //錯誤!!
	 int[] array4 = new int[]{1,2,3};//超愛考	 
	 //用於陣列宣告後給予數值 
	 array3 =new int[] {55,66};	 
    }
    
}
