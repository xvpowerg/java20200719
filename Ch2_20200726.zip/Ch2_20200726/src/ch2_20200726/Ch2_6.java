/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;

/**
 *
 * @author xvpow
 */
public class Ch2_6 {

    public static void main(String[] args) {
	// 左邊的[] 數量加起來等於右邊的[]
	int[][] array1 = new int[3][2];
	int[] array2[][] = new int[3][2][2];
	int array3[][][] = new int[3][2][2];
	
	int[][] array4 = { {5,6,7},  {11,12}};
	
	int[][][] array5 = new int[3][][];
	array5[0] = new int[3][2];
	int[][] tmpArray = new int[2][1];
	array5[1] =tmpArray;
	
	int[][][] array6 = new int[][][]{
	    {
		{1,2,5},{1,2}  
	    },
	    {
		{3,6,7}
	    }
	};
	System.out.println(array6[0][0][2]);
	System.out.println(array6[1][0][1]);
    }
    
}
