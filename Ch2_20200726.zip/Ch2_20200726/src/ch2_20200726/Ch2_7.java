/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;

/**
 *
 * @author xvpow
 */
public class Ch2_7 {
    public static void main(String[] args) {
	//在陣列中的例外
	//ArrayIndexOutOfBoundsException 
	//NullPointerException 
	
	int[][][] array = new int[3][][];
	array[0] = new int[][]{{1,2,3},{4,5}  };	
	array[2] = new int[2][];
	array[2][0] = new int[]{7,8,9};
	
	//System.out.println(array[0][0][2]);//3
	//System.out.println(array[0][1][2]);//java.lang.ArrayIndexOutOfBoundsException
	//System.out.println(array[1][0][0]);//java.lang.NullPointerException
	System.out.println(array[2][0][1]);
	
    }
    
}
