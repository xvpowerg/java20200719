/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;

/**
 *
 * @author xvpow
 */
public class Ch2_11 {

    
    static void division(float f1, int f2){
	if (f2 == 0){
	    System.out.println("分母不可為０");
	    //因為不想繼續做除法所以return
	    return; 
	}
	   float ans = f1/f2; 
	  System.out.println(ans);
    }
    
    public static void main(String[] args) {
	division(5,2);
	division(5,0);

    }
    
}
