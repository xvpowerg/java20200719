/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;

/**
 *
 * @author xvpow
 */
public class Ch2_8 {
	
    //1 是否需要回傳 如不回傳 標記為void
    //2 方法名稱
    //3 傳入參數 如果無參數 標記為() 
    //4 方法本體{}
    //靜態的只能直接呼叫靜態的
    static void test1(){
	System.out.println("Test1!");
    }
    
    static int pow(int n,int p){	
	int ans =1;
	for (int i =1;i<=p;i++){
	    ans *= n;
	}
	//return 的方法
	//1 如果有回傳值時 return 回傳數值
	//2 結束方法
	return ans;	
    }
	    
    public static void main(String[] args) {
	test1();
	int v = pow(2,3);
	System.out.println(v);
    }
}
