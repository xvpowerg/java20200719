/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;
import java.util.Arrays;

public class Ch2_3 {

    public static void main(String[] args) {
	//Arrays 物件的方法
	//排序 快速排序法
	//快速排序法原理
	//不斷使得左邊的數小於n右邊的數大於n
	int[] array = {20,7,11,9,15,17};
	Arrays.sort(array);
	for (int v :array){
	    System.out.print(v+" ");
	}
	System.out.println();
	//搜尋 二分搜尋法 
	//使用binarySearch之前陣列順序必須由小到大
	int index = Arrays.binarySearch(array, 15);
	System.out.println(index);
	//找不到的問題
	//假設要找的數值是n
	//1 n小於陣列所有數值 -1
	int index2 = Arrays.binarySearch(array, 2);
	System.out.println(index2);
	//2 n大於陣列所有數值 回傳 (陣列長度 + 1 ) * -1
	 int index3=   Arrays.binarySearch(array, 25);
	 System.out.println(index3);
	 //必考題
	//3 n介於陣列數值之間 找比n大一點的數字 位於的長度 *-1
	   // 7 9 11 15  17  20 
	  //   8       16    19
	int index4 = Arrays.binarySearch(array, 15);
	 System.out.println(index4);
	
    }
    
}
