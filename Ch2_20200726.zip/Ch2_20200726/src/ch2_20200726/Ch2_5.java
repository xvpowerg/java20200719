/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;

/**
 *
 * @author xvpow
 */
public class Ch2_5 {

    public static void main(String[] args) {
	//多維陣列
	//線性代數
	int[][] array1 = new int[2][3];
	
	array1[0][1] = 32;
	array1[1][0] = 71;
	array1[1][2] = 53;
		
	for (int r =0;r<array1.length;r++){
	    for (int c = 0; c <array1[r].length ;c++){
		 System.out.print(array1[r][c]+" ");
	    }	
	    System.out.println();
	}
	    //foreach
	for (int[] tmpArray : array1){
	    for (int v : tmpArray){
		System.out.print(v+" ");
	    }
	    System.out.println();
	}
	
	
    }
    

}
