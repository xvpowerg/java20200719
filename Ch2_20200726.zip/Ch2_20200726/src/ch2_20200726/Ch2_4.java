/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;
import java.util.Arrays;
public class Ch2_4 {
    public static void main(String[] args) {
	int[] array = {8,9,12,6,5,4,2,87,55,64,35};
	int[] newArray = Arrays.copyOf(array, array.length +10);
	for (int v :newArray){
	    System.out.print(v+" ");
	}
	 System.out.println();
	 //index >=2  index <= 8
	int[] newArray2 = Arrays.copyOfRange(array, 2,8);
	for (int v :newArray2){
	    System.out.print(v+" ");
	}
	 System.out.println();
	 String[] names = new String[1000];
	 Arrays.fill(names, "empty");
	 System.out.println(names[5].equals("A"));
    }
}
