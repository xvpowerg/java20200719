/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;
public class Ch2_10 {

  static void swap(String st1,String st2){
      String tmp = st1;
	st1 = st2;
	st2 = tmp;
  }
  static void swap(StringBuilder sb1,StringBuilder sb2){
        String tmp = sb1.toString();
    sb1.delete(0, sb1.length());
    sb1.append(sb2);
    sb2.delete(0, sb2.length());
    sb2.append(tmp);
  }
    public static void main(String[] args) {
	//字串擁有不可修改性
	//字串沒有方法可改變自己稱為(不可修改性)immutable
	String st1 = "A";
	String st2 = "B";	
	System.out.println(st1+":"+st2);
	swap(st1,st2);
	System.out.println(st1+":"+st2);

    StringBuilder sb1 = new StringBuilder();
    StringBuilder sb2 = new StringBuilder();
    sb1.append("A");
    sb2.append("B");
    System.out.println(sb1+":"+sb2);    
    swap(sb1,sb2);
    System.out.println(sb1+":"+sb2);
	
    }
    
}
