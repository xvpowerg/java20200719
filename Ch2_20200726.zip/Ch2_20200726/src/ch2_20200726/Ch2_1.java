/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;
import java.util.stream.IntStream;
/**
 *
 * @author xvpow
 */
public class Ch2_1 {

    public static void main(String[] args) {
	//陣列使用時機
	//1 宣告一群相同類型的變數時
	//2 演算法的需求
	//陣列的特性
	//1 一連串的記憶體空間
	//2 可以用index取得數值
	//3 index的最大數是陣列的長度-1
	//只要看到new相關的 類型就不是基本型態 是參考型態
	//陣列初始預設值
	//整數:0
	//浮點數:0.0
	//字元:空白字元
	//布林:false
	//參考型態:null	
	
	
	int[] myArray = new int[5];//5為陣列長度
	myArray[0] = 12;
	myArray[2] = 32;
	myArray[3] = 15;
	//length 為常數 不可修改
	//myArray.length = 100;
	for (int i = 0; i < myArray.length; i++){
	    System.out.print(myArray[i] +" ");
	}
	
	 System.out.println();
//       for(int i = 0; i < myArray.length;i++){
//	   int x = myArray[i];
//	   System.out.print(x+" ");
//       }
//for each
	for (int x : myArray){
	    System.out.print(x+" ");
	}
System.out.println();	
    //流行寫法使用Stream
    IntStream.of(myArray).
	    forEach(System.out::println );
     
    }
    
}
