/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20200726;

/**
 *
 * @author xvpow
 */
public class Ch2_9 {

    //方法對參數的變異性
    
    
    //call by value  所有基本型態
    //基本型態的參數不會改變
    static void swap(int a,int b){
	int tmp = a;
	a = b;
	b = tmp;
    }
    //call by reference  所有非基本型態
    //可能會被改變
    static void swap(int[] array){
	 int tmp = array[0];
	array[0] = array[1];
	array[1] = tmp;    
    }
    public static void main(String[] args) {
//	int a =10;
//	int b =20;
//	System.out.println(a+":"+b);
//	swap( a, b);
//	System.out.println(a+":"+b);

    int[] array = {62,31};
    System.out.println(array[0]+":"+array[1]);
    swap(array);
    System.out.println(array[0]+":"+array[1]);
	
	
    }
    
}
