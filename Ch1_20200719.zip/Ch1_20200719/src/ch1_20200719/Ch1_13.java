/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_13 {

    public static void main(String[] args) {
	//null 空無一物
	String name1 = null;
	String name2 = "Tom";
	//System.out.println(name1.equals(name2));//java.lang.NullPointerException
	//System.out.println(name2.equals(name1));	
	switch(name1){
	    case "Ken":
		System.out.println("經理");
		break;
	    case "Vivin":
		System.out.println("業務");		 
		break;
	    default:
		System.out.println("Error");
		break;
	}	
    }    
}
