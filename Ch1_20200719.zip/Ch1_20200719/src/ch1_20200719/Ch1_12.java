/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	//字串的比較
	String st1 = "Ken";
	String st2 = "Ken";
	String st3 = new String("Ken");
	//== 比較兩變數的內容是否相等
	System.out.println(st1 == st2);//true
	System.out.println(st1 == st3);//false
      //對字串來說用equals 去比是比較每個字元是否一樣
      //參考型態比較是否相等請使用equals    
	System.out.println(st1.equals(st2));
	System.out.println(st1.equals(st3));
	
	String value = "";
	for (int i =1; i<=26;i++){
	    value =value+ i;
	    value = value+",";
	}
	System.out.println(value);
	 //StringBuffer sb = new StringBuffer();
	 StringBuilder sb = new StringBuilder();
	for (int i =1; i<=26;i++){
		 sb.append(i);
		 sb.append(",");
	     }
	System.out.println(sb);
//	
   
	
    }
    
}
