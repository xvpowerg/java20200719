/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;
public class Ch1_1 {
    public static void main(String[] args) {
	int value = 10;
	System.out.println(value);
	//byte  8bit -128~127
	byte b1 = 11;
	//short  16bit -32768 ~ 32767
	//int 32bit -2147483648 ~ 2147483647  * 預設
	//long 64bit
	long max = 2147483648L;
	
	//浮點數 有小數點的數
	//float 32bit  6精準度 *
	  float e = 2.71828f;
	//double 64bit 14精準度 預設
	
	//char 16bit //0~65535 字元 Charactor
	String name = "Ken";    //字串
	char c1 = 'K';//字元
	System.out.println(c1);
	char c2 = 65;
	System.out.println(c2);
	
	char c3 = '三';
	char c4 = '倍';
	char c5 = '卷';
	
	int c3Number = c3;
	System.out.println(c3Number);
	//強制轉型
	System.out.println((int)c4);
	System.out.println((int)c5);
	//boolean 1bit
	boolean isOpen = false;
	//其他參考型別 無特定分配空間
	String url = "http://www.google.com";
	
	//1 問看看 記憶體 是否有空間存放
	//2 有 請記憶體分配某個位置
	//3  就把 10 放在 某個位置
	
	//CPU 中央處理器 運算 厲害整數運算
	//GPU 顯示卡 厲害 算浮點數
	//主機板
	
    }
}
