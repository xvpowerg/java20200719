/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	
	//是計算用的
	int x = 19; //10011
	int y = 28; //11100
	//&
	    System.out.println(x & y);
	//|
	    System.out.println(x | y);
	// xor
	   System.out.println(x ^ y);
	   
	// <<  t * (2 ^ n)
	int t = 8;
	int n = 2;
	 System.out.println(t << n ); 		 
	//>> k / (2 ^ n)
	int k = 8;
	n = 1;
        System.out.println(k >>n);
	
	
    }
    
}
