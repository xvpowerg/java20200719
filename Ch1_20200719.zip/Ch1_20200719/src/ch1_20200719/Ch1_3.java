/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_3 {

    public static void main(String[] args) {
	int i = 0;
	++i;
	System.out.println(i);
	i++;
	System.out.println(i);
	int k = i++;
	System.out.println(k);
	int y = ++i;
	System.out.println(y);
	
	
    }
    
}
