/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_10 {

    public static void main(String[] args) {
	//byte short int char String enum
	//在java 內 final 不可做什麼
	//變數加上final不可再重新給予數值
	final int RUN = 1;	
	final int JUMP = 2;
	final int WALK = 3;
	int action = WALK;
	//使用於case後的變數必須是常數
     switch(action){
	    case RUN:
		System.out.println("跑");
		break;
	    case JUMP:
		System.out.println("跳");
		break;	
	   default:	      
	    case WALK:
		System.out.println("走");   
		break;	
	}	
//標準型
//	switch(action){
//	    case 1:
//		System.out.println("跑");
//		break;
//	    case 2:
//		System.out.println("跳");
//		break;		
//	    case 3:
//		System.out.println("走");
//		break;
//	    default:
//		System.out.println("Error!");
//		break;
//	}
    }
    
}
