/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_4 {
// 運算優先子
    // () 一元運算(++ --)
    // * / %
    // + -
    // < > >= <=
    // == !=
    // &&
    // ||
    
    public static void main(String[] args) {
	int h = 3;	
	int ans = 5 + h-- * 2 + h++ - ++h ;
	//        5 + 3 * 2  + 2 - 4;
	// 5 + 6 +2 - 4
	System.out.println(ans);
	System.out.println(h);	
    }
    
}
