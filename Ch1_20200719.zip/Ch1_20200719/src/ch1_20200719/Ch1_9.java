/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_9 {

    public static void main(String[] args) {
// if 未加上{}要注意以下題目	 		
//	int i = 10;
//	if ( i < 20)
//	   System.out.println("A");
//	   System.out.println("B");//這會出錯
//	else
//	    System.out.println("C");
	
	
    }
    
}
