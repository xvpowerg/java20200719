/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_5 {

    public static void main(String[] args) {
	
	  int a = 10;
	  int b = 20;
	  int c = 40;
	  int k = 0;
	  //短路條件 當發生某件事時 不往下執行
	  //且　&& 兩邊都為true才為true
	  System.out.println(a > b && c > a);
	  //因為左邊為ture所以短路條件沒有啟動
	  System.out.println(a < b && a > ++k);
	  System.out.println(k);
	  //因為左邊為false所以短路條件啟動未執行k++
	  System.out.println(c < b && a > ++k);
	 System.out.println(k);
	 
	 int y = 0;
	 //或 || 單邊為true回傳true
	 //因為左邊為ture所以短路條件沒有啟動
	 System.out.println(c < b || a > ++y);
	 System.out.println(y);	 
	 //因為左邊為ture所以短路條件有啟動
	  System.out.println(c > b || a > ++y);
	  System.out.println(y);
	  
	  //xor 一真一假才為真
	  boolean b1 = true,b2 = false;
	  System.out.println(b1 ^ b2);
	  
	  
    }
    
}
