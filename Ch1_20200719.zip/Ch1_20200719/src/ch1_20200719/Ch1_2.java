/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_2 {

    public static void main(String[] args) {
	    // * / + -
	    //四則運算中 只要有浮點數 結果類型會變為浮點數
	    int totalHp = 5627;
	    float currentHp =3000;
	    float showHp = currentHp / totalHp * 100;
	    System.out.println(showHp);
	    //%.2f取道小數點第二位
	    //%% 印出%
	    //%n 斷行
	    System.out.printf("%.2f%%%n",showHp);
	   
//	    int ans = 20 / 0;
//	   System.out.println("ans:"+ans);
	   
	    int mod = 11 % 3;
	    int quotient = 11/3;
	    System.out.println("餘數:"+mod);
	    System.out.println("商數:"+quotient);
    }
    
}
