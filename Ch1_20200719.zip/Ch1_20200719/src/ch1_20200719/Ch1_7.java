/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	   
	int i = 10;
	int k = 5;
	float y = 7.2f;
	
	i+=k;	
	System.out.println(i);
	i+=y;//運算後結果會轉為整數
	System.out.println(i);
    }
    
}
