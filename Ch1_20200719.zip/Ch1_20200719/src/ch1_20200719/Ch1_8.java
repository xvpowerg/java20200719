/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_8 {


    public static void main(String[] args) {
	//必考
	//變數規則
	//開頭可以是英文 _ $
	//第二個開始可以是 英文 _ $ 數字
	//不可用keyword	
	int $$_$$$ = 10;
	
	//_ 可以加在哪?
	//_前後必須是底線或數字
	//0b 2進位
	int a = 0b10_110;
	//8進位
	int oct = 0_712; 	
	//16進位
	int hex = 0xFF11F__F;
	
    }
    
}
