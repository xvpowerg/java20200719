/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20200719;

/**
 *
 * @author xvpow
 */
public class Ch1_11 {

    public static void main(String[] args) {
	//case 右邊的參數會受到 switch參數影響類型
	byte b1 = 20;//-128~127
	switch(b1){
	    case 1:
		break;
	    case 127:
		break;
	}
	
	//case 參數不可重複
//	int action = 10;
//	switch(action){
//	    case 1:
//		break;
//	    case 1000:
//	      break;
//	    case 100:
//		break;
//	    case 10__00:
//		break;
//	}
	
	
	
    }
    
}
