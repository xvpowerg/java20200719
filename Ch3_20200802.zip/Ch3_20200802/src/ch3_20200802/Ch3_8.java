/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_8 {
    //Overloading
    //多載的特性
    //方法名稱要一樣
    //參數的數量或類型不一樣
    //Overloading 工作方式
    //依照方法的參數 類型或數量決定 要呼叫的方法
    //Overloading 好處
    //可省方法的命名

    static int abs(int a){
	return a <0 ? a*-1 : a;
    }
    static float abs(float a){
	return a < 0 ?a*-1:a;
    }

    public static void main(String[] args) {
	System.out.println(abs(-20));
	System.out.println(abs(-75));
	System.out.println(abs(-1.35f));
    }
    
}
