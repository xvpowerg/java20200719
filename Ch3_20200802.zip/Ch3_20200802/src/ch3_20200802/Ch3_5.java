/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	// TODO code application logic here
	//只有基本形態要封箱
	//基本形封箱類型
	//byte      Byte
	//short     Short
	//int       Integer
	//long      Long
	//flot      Float
	//double   Double
	//char    Character
	//boolan   Boolean
	//封箱 boxing
	//規定 
	//為了安全與方便

	//解封箱unboxing
	//開箱取出真實的物體
	
	
	//手動
	 //封箱
	 int age = 25;
	Integer ageObj  = Integer.valueOf(age);	 
	 //解封箱
	 int ageInt =   ageObj.intValue();
	 System.out.println(ageInt);
	 
       //自動
	  //封箱
	  Integer lenObj = 15;	  
	  //解封箱
	  int len = lenObj;
	  
    }
    
}
