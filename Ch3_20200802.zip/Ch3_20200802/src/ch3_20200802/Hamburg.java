/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Hamburg {
    String name;
    int price;
    float calories;
    
    void printInfo(){
	System.out.println(name+":"+price+":"+calories);
    }
}
