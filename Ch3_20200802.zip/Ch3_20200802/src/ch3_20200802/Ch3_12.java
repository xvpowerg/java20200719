/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_12 {

     //overloading的執行權重
    //1 一樣類型
    //2 相同類型可相容
    //假設方法的參數是long  傳入了一個int類型的數值
    //3 不同類型可相容
    //4 封箱類型
    
    static void test4(short s1){
	System.out.println("short");
    }
      static void test4(Float s1){
	System.out.println("Float");
    }
//     static void test4(Integer s1){
//	System.out.println("Integer");
//    }
    public static void main(String[] args) {
	// TODO code application logic here
	//test4(20);//Integer 不相容 Float  編譯錯誤
	//Integer iObj = Integer.valueOf(20);
	
    }
    
}
