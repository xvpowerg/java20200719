/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

public class Ch3_4 {
    public static void main(String[] args) {
	String ip = args[0] ;
	String account = args[1];
	String password = args[2];
	System.out.println("網路連線到:"+ip);
	System.out.println("帳號:"+account);
	System.out.println("密碼:"+password);
    }    
}
