/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_14 {
    public static void main(String[] args) {
	// TODO code application logic here
	//類別 生產的單據
	//物件 是由生產單據產生物品 獨立的
	
	//new 此關鍵字 才是創造物件
	Hamburg ham1 =  new Hamburg();
	ham1.calories = 500;
	ham1.name = "超級牛肉堡";
	ham1.price = 350;
	
	Hamburg ham2 = new Hamburg();
	ham2.calories = 300;
	ham2.name = "雞胸日式堡";
	ham2.price = 150;

	ham2.price = 70;
	
	ham1.printInfo();
	ham2.printInfo();
    }
    
}
