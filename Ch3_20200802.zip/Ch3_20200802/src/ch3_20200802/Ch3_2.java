/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_2 {

    static int factorial(int n){
	if (n == 1){ return 1;}
	return n * factorial(n-1);
    }
    
    public static void main(String[] args) {
	// TODO code application logic here
	//5!
	//5 * 4 * 3 * 2 * 1 
	//5! = 5 * 4!
	//4! = 4 * 3!
	//3! = 3 * 2!
	//2! = 2 * 1!
	System.out.print(factorial(6));
    }
    
}
