/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

public class Ch3_1 {
    //遞迴 遞迴次數不要過長
    static void test1(int i){ 
	
	System.out.println("test1 Start!"+i);
	if (i <= 3){
	    System.out.println(i);
	    test1(i + 1);	
	    
	}
	System.out.println("test1 End!"+i);
    }
    public static void main(String[] args) {
	//輸出1 2 3
	//test1(1);
	
	for (int i =1; i <= 1000000;i++){
	    System.out.println(i);
	}
    }
  
}
