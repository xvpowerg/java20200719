/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */

public class Student {
    
    String name;
    //private 私有的只有目前的類別可讀寫
    private int age;
    //set 存錢
    public void setAge(int inAge){
	if (inAge < 0 || inAge > 200){
	    System.out.println("錯誤的年齡");
	}else{
	  age = inAge;  
	}
    }    
    public int getAge(){
	return age;
    }
    
    void printInfo(){
	System.out.println(name+":"+age);
    }
    
}
