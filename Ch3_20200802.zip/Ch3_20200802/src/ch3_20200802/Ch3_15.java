/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_15 {

    /**
     * @param args the command line arguments
     */
    //Encapsulation 封裝
    //第一步 把要封裝的屬性設為私有
    //第二步 設定公開的方法讀取與寫入
    public static void main(String[] args) {
	Student st1 = new Student();
	st1.name = "Ken";
	st1.setAge(10);
	System.out.println(st1.getAge());
	st1.printInfo();
    }
    
}
