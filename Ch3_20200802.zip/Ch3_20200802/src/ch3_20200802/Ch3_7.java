/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_7 {

    public static void main(String[] args) {
	
	Boolean b1Obj =  Boolean.valueOf(true);
	System.out.println(b1Obj.booleanValue());
	
	
	//Boolean.parseBoolean 參數只要是true 不分大小寫　就回傳true
	//其餘的都回傳false 不會拋出錯誤
	String bStr = "true";
	boolean b1 = Boolean.parseBoolean(bStr);
	System.out.println(b1);
	
	bStr = "tRuE";
	b1 = Boolean.parseBoolean(bStr);
	System.out.println(b1);
	
	bStr = "tr ue";
	b1 = Boolean.parseBoolean(bStr);
	System.out.println(b1);
	
	bStr = "asdasdasdasd";
	b1 = Boolean.parseBoolean(bStr);
	System.out.println(b1);
    }
    
}
