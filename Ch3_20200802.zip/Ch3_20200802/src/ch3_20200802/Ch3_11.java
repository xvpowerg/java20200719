/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_11 {

     //overloading的執行權重
    //1 一樣類型
    //2 相同類型可相容
    //假設方法的參數是long  傳入了一個int類型的數值
    //3 不同類型可相容
    //4 封箱類型
    
    static void test3(float f1){
	System.out.println("float");
    }
    static void test3(Integer v2){
	System.out.println("Integer");
    }
    public static void main(String[] args) {
	
	test3(20);//float
	
    }
    
}
