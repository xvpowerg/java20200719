/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_13 {
	     //overloading的執行權重
    //1 一樣類型
    //2 相同類型可相容
    //假設方法的參數是long  傳入了一個int類型的數值
    //3 不同類型可相容
    //4 封箱類型
    //多參數的方法時 一定要有一個可確定的選項
    static void test5(int v1,float v2){
	System.out.println("int float");
    }
    static void test5(int v1,int v2){
	System.out.println("int int");
    }
    
    static void test6(int v1,int v3,float v2){
	System.out.println("int int float");
    }
      static void test6(float v1,int v3,int v2){
	System.out.println("float int int");
    }
      
      
    public static void main(String[] args) {
	// TODO code application logic here
	test5(10,20);
	test6(10,15,20f);//無法判定該選誰 編譯錯誤
    }
    
}
