/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_3 {

    //長參數 vargs
    //長參數 看為陣列  
    static int sum(int ... a){
	int sum  = 0;
	for(int v :a){
	    sum += v;
	}
	return sum;
    }
     //長參數 必須是方法的最後一個參數
    //以下錯誤因為vargs不是最後一個參數
//    static void testVargs(String ... name,int max){
//	
//    }

    public static void main(String... args) {
	// TODO code application logic here
	System.out.println(sum());	
	System.out.println(sum(5,2,6));
	System.out.println(sum(5,2,6,8,9,10));
	int[] array = {7,1,2,3};
	System.out.println(sum(array));//會展開array 放到長參數內	
	
    }
    
}
