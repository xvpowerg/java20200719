/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_6 {
    public static void main(String[] args) {
	//Integer 好用方法
	//字串轉整數
	
	String value1 = "51";
	//字串數字轉整數
	int intValue1 = Integer.parseInt(value1);
	System.out.println(intValue1+10);
	double d1 =  Double.parseDouble(value1);
	System.out.println(d1);
	
	//10進位轉
	int signal = 5678;
	//為2進位
	System.out.println(Integer.toBinaryString(signal));
	//為8進位
	System.out.println(Integer.toOctalString(signal));
	//為16進位
	System.out.println(Integer.toHexString(signal));
	
    }
    
}
