/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20200802;

/**
 *
 * @author xvpow
 */
public class Ch3_9 {
    //overloading的執行權重
    //1 一樣類型
    //2 相同類型可相容
    //假設方法的參數是long  傳入了一個int類型的數值
    //3 不同類型可相容
    //4 封箱類型
    
    static void test1(long v1){
	System.out.println("long");
    }
    static void test1(short v2){
	System.out.println("short");
    }
    static void test1(float v2){
	System.out.println("float");
    }
    
    
    public static void main(String[] args) {
	// TODO code application logic here
	short shortV1 = 25;
	int intV2 = 76;
	test1(shortV1);
	test1(intV2);

    }
    
}
