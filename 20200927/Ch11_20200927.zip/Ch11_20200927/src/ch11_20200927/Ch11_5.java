/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200927;

import java.util.ArrayList;

/**
 *
 * @author xvpow
 */
public class Ch11_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	 ArrayList<String> list = new ArrayList<>();
	 list.add("Howard");
	 list.add("Vivin");
	 list.add("Lindy");
	 list.add("Ken");
	 list.add("Tom");
	 //全部符合條件回傳true
//	boolean b1 = 
//		list.stream().peek(v->System.out.println("Peek:"+v)).allMatch(n->n.length() >2);
//	System.out.println(b1);
//	boolean b2 = list.stream().peek(v->System.out.println("Peek:"+v)).
//		allMatch(n->n.length() >3);
//	System.out.println(b2);
//	 //其中之一符合條件回傳true
//	boolean b3 = 
//		list.stream().peek(v->System.out.println(v)).
//			anyMatch(n->n.length()<5);
//	System.out.println(b3);
	//所有條件都不符合回傳true
//boolean b4 = list.stream().
//		peek(v->System.out.println(v)).noneMatch(n->n.length() > 10);
//	 System.out.println(b4);
	boolean b5 = list.stream().
		peek(v->System.out.println(v)).noneMatch(n->n.length() > 3);
	 System.out.println(b5); 
    }
    
}
