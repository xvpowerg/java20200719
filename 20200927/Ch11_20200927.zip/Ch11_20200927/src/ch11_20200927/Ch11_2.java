/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20200927;
import java.util.List;
import java.util.ArrayList;
public class Ch11_2 {
//? extends Test2 不可add內容到List
    //但可以取得數值
    //主要用來顯示資料
    static void testList(List<? extends Test2> list){
	for (Test2 t2 : list){
	    System.out.println(t2);
	}
    }
    //? super 意思
    //傳入參數的泛型 必須是某類型的父類型0 或一樣 
    //可以新增 但是新增類型只能是 super 後的子類型或一樣
    //也可以取值 類型是Object
    static void testSuper(List<? super Test2> list){	
	Test3 t1 = new Test3();
	list.add(t1);
	for (Object t :list ){
	    System.out.println(t);
	}
    }
    public static void main(String[] args) {
//	List<Test3>  myList = new ArrayList<>();
//	Test3 t2 = new Test3();
//	Test3 t3 = new Test3();
//	Test3 t4 = new Test3();
//	
//	myList.add(t2);
//	myList.add(t3);
//	myList.add(t4);
//	testList(myList);
	
	List<Test1>  myList2 = new ArrayList<>();
	Test1 t2 = new Test1();
	Test1 t3 = new Test1();
	Test1 t4 = new Test1();
	myList2.add(t2);
	myList2.add(t3);
	myList2.add(t4);
	testSuper(myList2);
    }
    
}
